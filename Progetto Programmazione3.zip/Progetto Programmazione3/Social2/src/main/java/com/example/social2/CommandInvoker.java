package com.example.social2;

public class CommandInvoker {
    private Interfaccia_Command command;

    public void setCommand(Interfaccia_Command command) {
        this.command = command;
    }

    public void executeCommand() {
        if (command != null) {
            command.execute();
        } else {
            System.out.println("Command not set. Cannot execute.");
        }
    }
}