package com.example.social2;
import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Dialog;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

import java.io.*;
import java.util.*;
import org.json.simple.JSONObject;

public class SocialMediaController {
    private Map<String, PrivateChat> privateChats = new HashMap<>();

    public String getCurrentUser() {
        return currentUser;
    }

    private String currentUser;
    private String currentPassword;

    @FXML
    private TextField searchBar;

    @FXML
    private ListView<String> userList;

    @FXML
    private Button followButton;

    @FXML
    private TextArea messageInput;

    @FXML
    private Label charCountLabel;

    private Stage primaryStage;

    @FXML
    private VBox messageContainer;

    @FXML
    private Button registerButton;

    private SocialMediaApp mainApp;
    private String selectedUser;

    private Map<String, List<String>> privateChatSubscribers = new HashMap<>();
    private Map<String, List<String>> publicChatSubscribers = new HashMap<>();

    private List<User> registeredUsers = new ArrayList<>();


    private RegisterUserController registerUserController;

    private Map<String, List<String>> followersMap = new HashMap<>();

    private boolean loggedIn = false;

    public void setRegisterUserController(RegisterUserController registerUserController) {
        this.registerUserController = registerUserController;
    }



    public PrivateChat getPrivateChat(String currentUser, String otherUser) {
        String chatKey = currentUser + "_" + otherUser;
        return privateChats.get(chatKey);
    }

    public void setMainApp(SocialMediaApp mainApp) {
        this.mainApp = mainApp;
    }

    public List<String> getRegisteredUsers() {
        List<String> usernames = new ArrayList<>();
        for (User user : registeredUsers) {
            usernames.add(user.getUsername());
        }
        return usernames;
    }

    public static class User {
        private String username;
        private String password;

        public User(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }
    }


    public void setCurrentUser(String currentUser) {
        this.currentUser = currentUser;
    }

    public void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }


    private String capitalize(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }


    private void searchUsers() {
        String searchText = searchBar.getText().toLowerCase();
        userList.getItems().clear();

        // Carica gli utenti da Users.json utilizzando UserDataService
        List<User> users = UserDataService.loadUsers();

        // Aggiungi gli utenti al userList
        for (User user : users) {
            if (user.getUsername().toLowerCase().contains(searchText)) {
                userList.getItems().add(user.getUsername());
            }
        }
    }

    private void addUserToUserList(String userName) {
        userList.getItems().add(capitalize(userName));
    }

    @FXML
    private void showFollowButton() {
        String selectedUser = userList.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            followButton.setText("Follow " + selectedUser);
            followButton.setDisable(false);
        }
    }

    private void showLoginAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Avviso");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    @FXML
    private void openUserSelectionDialog(ActionEvent event) {
        if (!isLoggedIn()) {
            showLoginAlert("Devi prima registrarti o fare il login prima di poter avviare una chat.");
            return;
        }

        String selectedUser = userList.getSelectionModel().getSelectedItem();
        openUserSelectionDialog(selectedUser);
    }



    private void openUserSelectionDialog(String selectedUser) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("user_selection_dialog.fxml"));
            Parent root = loader.load();
            String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();
            root.getStylesheets().add(css); // Fix: Use 'root' instead of 's'

            UserSelectionDialogController userSelectionDialogController = loader.getController();
            userSelectionDialogController.initData(this, selectedUser, privateChats);

            Stage userSelectionDialogStage = new Stage();
            userSelectionDialogStage.initModality(Modality.APPLICATION_MODAL);
            userSelectionDialogStage.setTitle("Select User");
            userSelectionDialogStage.setScene(new Scene(root));

            userSelectionDialogStage.showAndWait();

            // Check if a user was selected in the dialog
            if (userSelectionDialogController.isUserSelected()) {
                String selectedRecipient = userSelectionDialogController.getSelectedUser();
                openPrivateChat(currentUser, selectedRecipient);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<String> getFollowedUsers() {
        List<String> followedUsers = followersMap.get(currentUser);
        return followedUsers != null ? followedUsers : new ArrayList<>();
    }

    private String showUserSelectionDialog(List<String> users) {
        ChoiceDialog<String> dialog = new ChoiceDialog<>(null, users);
        dialog.setTitle("Select User");
        dialog.setHeaderText("Select a user to chat with:");
        dialog.setContentText("User:");

        Optional<String> result = dialog.showAndWait();
        return result.orElse(null);
    }

    private boolean areMutualFollowers(String user1, String user2) {
        List<String> followersUser1 = followersMap.get(user1);
        List<String> followersUser2 = followersMap.get(user2);

        return followersUser1 != null && followersUser2 != null &&
                followersUser1.contains(user2) && followersUser2.contains(user1);
    }


    private void openPrivateChat(String currentUser, String recipient) {
        String chatKey = currentUser + "_" + recipient;
        String reverseChatKey = recipient + "_" + currentUser;

        // Verifica se la chat esiste già tra i due utenti
        if (privateChats.containsKey(chatKey)) {
            // Se la chat esiste, apri quella esistente
            showPrivateChat(recipient, privateChats.get(chatKey));
        } else if (privateChats.containsKey(reverseChatKey)) {
            // Se la chat inversa esiste, apri quella esistente
            showPrivateChat(recipient, privateChats.get(reverseChatKey));
        } else {
            // Altrimenti, crea una nuova chat
            PrivateChat privateChat = new PrivateChat(recipient);
            privateChats.put(chatKey, privateChat);
            showPrivateChat(recipient, privateChat);
        }
    }

    @FXML
    private void followUser() {
        String selectedUser = userList.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            if (selectedUser.equals(currentUser)) {
                // L'utente sta cercando di seguirsi da solo
                showAlert("Errore", "Impossibile seguire se stessi", "Un utente non può seguirsi da solo.");
            } else {
                String followMessage = currentUser + " ha seguito " + selectedUser;
                showNotification(followMessage);

                addFollower(selectedUser, currentUser);
                openPrivateChat(currentUser, selectedUser);
            }
        }
    }

    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void addFollower(String followedUser, String follower) {
        if (!followersMap.containsKey(followedUser)) {
            followersMap.put(followedUser, new ArrayList<>());
        }

        // Aggiungi il follower solo se non è già presente
        List<String> currentFollowers = followersMap.get(followedUser);
        if (!currentFollowers.contains(follower)) {
            currentFollowers.add(follower);
            System.out.println("Follower aggiunto: " + follower + " a " + followedUser);

            // Senza la gestione delle eccezioni perché saveFollowersInfo non dichiara IOException
            saveFollowersInfo();
        } else {
            System.out.println("Il follower " + follower + " è già presente per " + followedUser);
        }
    }



    private void showUsernameTakenAlert(String username) {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Username già in uso");
        alert.setHeaderText("L'username '" + username + "' è già stato scelto.");
        alert.setContentText("Scegli un altro username.");

        alert.showAndWait();
    }

    @FXML
    private void handleRegisterButton() {
        try {
            if (!loggedIn) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("RegisterUser.fxml"));
                Parent root = loader.load();

                RegisterUserController registerController = loader.getController();
                registerController.setRegisterUserCallback((username, password) -> {
                    if (isUsernameTaken(username)) {
                        // Mostra un popup di errore per username già esistente
                        showUsernameTakenAlert(username);
                    } else {
                        registerUser(username, password);
                        currentUser = username;
                        loggedIn = true;
                        currentPassword = password;
                        // Mostra il popup di benvenuto
                        showWelcomePopup(username);
                    }
                });

                Stage registrationStage = new Stage();
                Scene registrationScene = new Scene(root);

                // Aggiungi lo stile CSS alla scena appena creata
                String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();
                registrationScene.getStylesheets().add(css);

                registrationStage.setScene(registrationScene);
                registrationStage.show();
            } else {
                System.out.println("You are already logged in");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void showWelcomePopup(String username) {
        Alert welcomeAlert = new Alert(AlertType.INFORMATION);
        welcomeAlert.setTitle("Benvenuto");
        welcomeAlert.setHeaderText(null);
        welcomeAlert.setContentText("Benvenuto, " + username + " :-)");
        welcomeAlert.showAndWait();
    }

    private boolean isUsernameTaken(String username) {
        for (User user : registeredUsers) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }


    private void saveFollowersInfo() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("followersInfo.dat"))) {
            oos.writeObject(followersMap);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateCharCount() {
        int remainingChars = 140 - messageInput.getText().length();
        charCountLabel.setText("Caratteri rimasti: " + remainingChars);

        messageInput.setEditable(remainingChars > 0);
    }

    @FXML
    private void sendMessage() {
        if (!isLoggedIn()) {
            showLoginAlert("Devi prima registrarti o fare il login prima di poter scrivere qualcosa.");
            return;
        }

        String selectedUser = userList.getSelectionModel().getSelectedItem();

        if (currentUser != null && selectedUser != null) {
            String chatKey = currentUser + "_" + selectedUser;

            PrivateChat privateChat = privateChats.get(chatKey);
            if (privateChat == null) {
                privateChat = new PrivateChat(selectedUser);
                privateChats.put(chatKey, privateChat);
            }

            // Assuming PrivateChatController has a method like addMessage
            privateChat.getController().addMessage(currentUser + ": " + messageInput.getText());

            privateChats.put(chatKey, privateChat);

            showPrivateChat(selectedUser, privateChat);
        } else {
            // If no user is selected, post the message to the public chat
            postMessageToPublicChat();
        }
    }

    public String getMessageInputText() {
        return messageInput.getText();
    }

    private void addMessageToPublicChat(String message) {
        // Assuming there is a method to display messages in the public chat
        messageContainer.getChildren().add(new Label(message));
    }
    @FXML
    private void postMessageToPublicChat() {
        if (!isLoggedIn()) {
            showLoginAlert("Devi prima registrarti o fare il login prima di poter scrivere qualcosa.");
            return;
        }

        String message = currentUser + ": " + messageInput.getText();

        // Utilizza la classe PublicDataManager per aggiungere il messaggio al file public.json
        PublicDataManager.addMessageToPublicChat(message, new ArrayList<String>());

        // Aggiorna l'interfaccia grafica o esegui altre azioni necessarie
        addMessageToPublicChat(message);

        // Cancella l'input e aggiorna il conteggio dei caratteri
        messageInput.clear();
        updateCharCount();
    }


    // Helper method to notify followers about a new post
    private void notifyFollowers(String poster, String message) {
        List<String> followers = followersMap.get(poster);

        if (followers != null && !followers.isEmpty()) {
            for (String follower : followers) {
                String notification = poster + " ha pubblicato un nuovo messaggio: " + message;
                PrivateChat followerChat = privateChats.get(follower + "_" + poster);

                if (followerChat != null && followerChat.getController() != null) {
                    followerChat.getController().addMessage(notification);
                    showPrivateChat(poster, followerChat);
                }
            }
        }
    }


    private void showPrivateChat(String selectedUser, PrivateChat privateChat) {
        Scene privateChatScene = null; // Declare the variable outside the try block
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("private_chat.fxml"));
            Parent root = loader.load();

            PrivateChatController controller = loader.getController();
            controller.setPrivateChat(privateChat);
            String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();

            // Assuming 'sce' was a typo and should be 'privateChatScene'
            privateChatScene = new Scene(root);
            privateChatScene.getStylesheets().add(css);

            // Initialize the chat window with message history
            controller.initialize(selectedUser, privateChat.getPrimaryStage());

            Stage privateChatStage = new Stage();
            privateChatStage.initModality(Modality.APPLICATION_MODAL);
            privateChatStage.setTitle("Chat with " + selectedUser);

            privateChatStage.setScene(privateChatScene);

            // Set the main stage as the owner of the private chat window
            privateChatStage.initOwner(primaryStage);

            privateChatStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setMessageInputReadOnly(boolean readOnly) {
        messageInput.setEditable(!readOnly);
    }

    @FXML
    private void showNotification() {
        String message = "This is a notification message.";
        showNotification(message);
    }

    private void showNotification(String message) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("notification.fxml"));
            Parent root = loader.load();

            NotificationController notificationController = loader.getController();
            // Modifica qui per passare entrambi gli argomenti necessari al metodo showNotification
            notificationController.showNotification(message, "");

            Stage notificationStage = new Stage();
            notificationStage.initModality(Modality.APPLICATION_MODAL);
            notificationStage.setTitle("Notification");
            notificationStage.setScene(new Scene(root));
            notificationStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void handleSearchButton() {
        searchUsers();
    }


    @FXML
    private void handleLogButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("log.fxml"));
            Parent root = loader.load();

            LogController logController = loader.getController();
            logController.setSocialMediaController(this);

            Stage logStage = new Stage();
            Scene logScene = new Scene(root);

            // Aggiungi lo stile CSS alla scena appena creata
            String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();
            logScene.getStylesheets().add(css);

            logStage.setScene(logScene);
            logStage.showAndWait();

            if (logController.isLoginSuccessful()) {
                String enteredUsername = logController.getUsername();
                String enteredPassword = logController.getPassword();

                List<User> users = UserDataService.loadUsers();
                Optional<User> matchingUser = users.stream()
                        .filter(user -> user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword))
                        .findFirst();

                if (matchingUser.isPresent()) {
                    currentUser = enteredUsername;
                    loggedIn = true;
                    System.out.println("Login successful for user: " + currentUser);

                    // Continua con il resto della logica di login, se necessario

                } else {
                    System.out.println("Username or password is incorrect");
                    // Mostra un messaggio di errore o esegui altre azioni in caso di credenziali errate
                }
            } else {
                for (PrivateChat privateChat : privateChats.values()) {
                    privateChat.getPrimaryStage().close(); // Chiudi le finestre di PrivateChat
                }
                System.out.println("Login canceled");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }






    private void registerUser(String username, String password) {
        System.out.println("User registered in SocialMediaController:");
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        User newUser = new User(username, password);
        registeredUsers.add(newUser);

        // Salva gli utenti, inclusi quelli appena registrati, in Users.json
        UserDataService.saveUsers(registeredUsers);

        searchUsers();
    }

    private void loadFollowersInfo() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("followersInfo.dat"))) {
            followersMap = (Map<String, List<String>>) ois.readObject();
        } catch (FileNotFoundException e) {
            followersMap = new HashMap<>();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }



    // Metodo per impostare la primaryStage
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    private MainController mainController;

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    // Aggiungi il metodo per tornare alla schermata principale
    @FXML
    private void handleBackToMainButton() {
        mainController.backToMainApp();
    }

    private void loadPublicMessages() {
        List<JSONObject> publicMessages = PublicDataManager.loadPublicMessages();

        // Assuming there is a method to display public messages in the message container
        for (JSONObject messageJson : publicMessages) {
            String messageContent = (String) messageJson.get("contenuto");
            // If you want to extract hashtags, you can do that here as well
            addMessageToPublicChat(messageContent);
        }
    }


    @FXML
    private void initialize() {
        loadFollowersInfo();
        loadPublicMessages();
    }}