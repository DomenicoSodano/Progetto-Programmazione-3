package com.example.social2;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NotificationController {

    @FXML
    private Label messageLabel;

    private List<Notification> notifications;

    private NotificationSavingStrategy savingStrategy = new JsonSavingStrategy();


    private static final String NOTIFICATIONS_FILE_PATH ="src/main/resources/com/example/social2/notifiche.json";
    public NotificationController() {
        // Carica le notifiche esistenti dal file JSON
        loadNotifications();
    }

    public void showNotification(String follower, String followed) {
        // Verifica se hai già seguito l'utente prima di aggiungere la notifica
        if (!isAlreadyFollowing(follower, followed)) {
            String message = follower + "" + followed;
            // Implementa la logica per visualizzare la notifica nella tua UI
            messageLabel.setText(message);

            // Salva la notifica nel file JSON solo se non hai già seguito l'utente
            Notification notification = new Notification(follower, followed);
            notifications.add(notification);
            saveNotifications();
        } else {
            // Mostra un pop-up o un messaggio avvisando che hai già seguito quell'utente
            showAlert("Attenzione", "Utente già seguito", "Hai già seguito questo utente.");
        }
    }

    // Aggiungi un metodo per verificare se hai già seguito l'utente
    private boolean isAlreadyFollowing(String follower, String followed) {
        for (Notification notification : notifications) {
            if (notification.getFollower().equals(follower) && notification.getFollowed().equals(followed)) {
                return true;
            }
        }
        return false;
    }

    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void loadNotifications() {
        notifications = new ArrayList<>();
        JSONParser parser = new JSONParser();

        try (FileReader reader = new FileReader(NOTIFICATIONS_FILE_PATH)) {
            Object obj = parser.parse(reader);

            if (obj instanceof JSONArray) {
                JSONArray jsonArray = (JSONArray) obj;

                for (Object item : jsonArray) {
                    if (item instanceof JSONObject) {
                        JSONObject jsonNotification = (JSONObject) item;
                        String follower = (String) jsonNotification.get("follower");
                        String followed = (String) jsonNotification.get("followed");
                        notifications.add(new Notification(follower, followed));
                    }
                }
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    private void saveNotifications() {
        try {
            savingStrategy.saveNotifications(notifications, NOTIFICATIONS_FILE_PATH);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setSavingStrategy(NotificationSavingStrategy savingStrategy) {
        this.savingStrategy = savingStrategy;
    }

    // Rimani invariato per la classe Notification
    public class Notification {
        private String follower;
        private String followed;

        public Notification(String follower, String followed) {
            this.follower = follower;
            this.followed = followed;
        }

        public String getFollower() {
            return follower;
        }

        public void setFollower(String follower) {
            this.follower = follower;
        }

        public String getFollowed() {
            return followed;
        }

        public void setFollowed(String followed) {
            this.followed = followed;
        }
    }
}