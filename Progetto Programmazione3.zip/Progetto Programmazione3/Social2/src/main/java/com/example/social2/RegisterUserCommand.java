package com.example.social2;

public class RegisterUserCommand implements Interfaccia_Command {
    private RegisterUserController controller;

    public RegisterUserCommand(RegisterUserController controller) {
        this.controller = controller;
    }

    @Override
    public void execute() {
        controller.registerUser();
    }
}