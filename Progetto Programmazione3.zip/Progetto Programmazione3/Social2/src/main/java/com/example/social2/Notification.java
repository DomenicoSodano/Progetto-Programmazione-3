package com.example.social2;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Notification extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("notification.fxml"));

        // Load the root from the FXML file
        Parent root = loader.load();

        primaryStage.setTitle("Notification Example");
        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }

}
