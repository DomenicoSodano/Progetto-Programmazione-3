// User.java
package com.example.social2;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private String username;
    private String hashedPassword;

    // Package-private constructor
    User(String username, String hashedPassword) {
        this.username = username;
        this.hashedPassword = hashedPassword;
    }

    public String getUsername() {
        return username;
    }

    public String getHashedPassword() {
        return hashedPassword;
    }

    // Metodo statico per ottenere un'istanza del builder
    public static UserBuilder builder() {
        return new ConcreteUserBuilder();
    }

    public static void main(String[] args) {
        // Esempio di utilizzo del Builder per creare un oggetto User
        User user = User.builder()
                .setUsername("john_doe")
                .setHashedPassword("hashed_password")
                .build();

        System.out.println("Username: " + user.getUsername());
        System.out.println("Hashed Password: " + user.getHashedPassword());
    }
}