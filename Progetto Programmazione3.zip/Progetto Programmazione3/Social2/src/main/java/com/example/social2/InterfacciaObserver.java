package com.example.social2;
import java.util.List;


public interface InterfacciaObserver {
    void updateMessages(List<AdminMessage.Messaggio> messages);
}