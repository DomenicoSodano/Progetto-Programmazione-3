package com.example.social2;

import java.util.List;

public class PublicMessage {

    private String messageContent;
    private List<String> hashtags;

    public PublicMessage(String messageContent, List<String> hashtags) {
        this.messageContent = messageContent;
        this.hashtags = hashtags;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public List<String> getHashtags() {
        return hashtags;
    }
}
