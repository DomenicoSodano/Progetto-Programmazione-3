package com.example.social2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;

import java.util.Optional;

import javafx.stage.Stage;import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.example.social2.SocialMediaController.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.example.social2.SocialMediaController.User;
import javafx.scene.control.Label;
import javafx.scene.control.Label;

public class AdminWelcomeController {
    @FXML
    private Button btnBack;


    @FXML
    private ListView<String> utentiListView;

    @FXML
    private ListView<String> hashtagListView;

    @FXML
    private Button btnEliminaUtente;

    private ObservableList<String> utentiList;
    private ObservableList<String> hashtagList;

    @FXML
    private Label welcomeLabel;

    @FXML
    private void initialize() {
        // Inizializza le liste con gli utenti registrati
        utentiList = FXCollections.observableArrayList();

        // Load users from the UserDataService
        List<User> loadedUsers = UserDataService.loadUsers();

        // Add loaded users to utentiList
        utentiList.addAll(loadedUsers.stream().map(User::getUsername).collect(Collectors.toList()));

        // Nascondi le liste all'inizio
        utentiListView.setVisible(false);
        hashtagListView.setVisible(false);
        btnEliminaUtente.setVisible(false);

        // Aggiungi l'EventHandler per gestire i clic sulla lista degli utenti
        utentiListView.setOnMouseClicked(event -> handleClicUtente());
    }



    public void setWelcomeMessage(String username) {
        if (welcomeLabel != null) {
            welcomeLabel.setText("Benvenuto, " + username + "!");
        } else {
            System.out.println("Error: welcomeLabel is null.");
        }
    }
    @FXML
    private void handleBack() {
        // Implementazione del metodo handleBack
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
    }


    @FXML
    private void handleVisualizzaUtenti() {
        // Logica per la visualizzazione degli utenti
        System.out.println("Visualizza Utenti:");
        for (String utente : utentiList) {
            System.out.println(utente);
        }

        // Mostra la lista degli utenti
        utentiListView.setItems(utentiList);
        utentiListView.setVisible(true);
        hashtagListView.setVisible(false);  // Nascondi la lista degli hashtag
        btnEliminaUtente.setVisible(true);  // Mostra il bottone "Elimina Utente"
    }


    @FXML
    private void handleClicUtente() {
        // Metodo chiamato al clic su un utente
        System.out.println("Clic su un utente");
    }

    @FXML
    private void handleEliminaUtente() {
        // Ottieni l'utente selezionato
        String utenteSelezionato = utentiListView.getSelectionModel().getSelectedItem();

        // Verifica se un utente è stato selezionato
        if (utenteSelezionato != null) {
            // Mostra una finestra di conferma
            Alert confermaEliminazione = new Alert(Alert.AlertType.CONFIRMATION);
            confermaEliminazione.setTitle("Conferma Eliminazione");
            confermaEliminazione.setHeaderText("Sei sicuro di voler eliminare l'utente?");
            confermaEliminazione.setContentText("L'utente '" + utenteSelezionato + "' verrà rimosso definitivamente.");

            Optional<ButtonType> result = confermaEliminazione.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Chiamare il metodo per eliminare l'utente dal file JSON
                UserDataService.eliminaUtente(utenteSelezionato);

                // Rimuovi l'utente dalla lista
                utentiList.remove(utenteSelezionato);

                // Aggiorna la lista visualizzata
                utentiListView.setItems(utentiList);

                // Mostra una notifica di eliminazione
                mostraNotifica("Utente '" + utenteSelezionato + "' eliminato con successo.");
            }
        } else {
            // Mostra un messaggio se nessun utente è stato selezionato
            mostraNotifica("Nessun utente selezionato per l'eliminazione.");
        }
    }



    private void mostraNotifica(String messaggio) {
        Alert notifica = new Alert(Alert.AlertType.INFORMATION);
        notifica.setTitle("Notifica");
        notifica.setHeaderText(null);
        notifica.setContentText(messaggio);
        notifica.showAndWait();
    }
    @FXML
    private void handleVisualizzaHashtag() {
        // Crea un'istanza di AdminHashtag e chiama il metodo start
        AdminHashtag adminHashtag = new AdminHashtag();
        try {
            adminHashtag.start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
