package com.example.social2;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
public class JsonSavingStrategy implements NotificationSavingStrategy {
    @Override
    public void saveNotifications(List<NotificationController.Notification> notifications, String filePath) throws IOException {
        JSONArray jsonArray = new JSONArray();
        for (NotificationController.Notification notification : notifications) {
            JSONObject jsonNotification = new JSONObject();
            jsonNotification.put("follower", notification.getFollower());
            jsonNotification.put("followed", notification.getFollowed());
            jsonArray.add(jsonNotification);
        }

        try (FileWriter fileWriter = new FileWriter(filePath)) {
            fileWriter.write(jsonArray.toJSONString());
        }
    }
}