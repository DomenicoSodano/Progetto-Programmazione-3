package com.example.social2;

import java.util.ArrayList;
import java.util.List;

public class AdminMessageNotifier {
    private final List<InterfacciaObserver> observers = new ArrayList<>();

    public void addObserver(InterfacciaObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(InterfacciaObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers(List<AdminMessage.Messaggio> messages) {
        for (InterfacciaObserver observer : observers) {
            observer.updateMessages(messages);
        }
    }
}
