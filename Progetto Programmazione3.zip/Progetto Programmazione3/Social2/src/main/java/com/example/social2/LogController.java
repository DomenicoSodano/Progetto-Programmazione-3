package com.example.social2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.util.Pair;

import java.util.Optional;
import java.util.List;
import java.util.Optional;
import com.example.social2.SocialMediaController.User;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
public class LogController {


    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private boolean loginSuccessful = false;

    public boolean isLoginSuccessful() {
        // Implementa la logica necessaria per verificare se il login è avvenuto con successo
        return loginSuccessful;
    }

    public String getUsername() {
        // Restituisci l'username attualmente inserito nella finestra di login
        return usernameField.getText();
    }

    public String getPassword() {
        // Restituisci la password attualmente inserita nella finestra di login
        return passwordField.getText();
    }

    private SocialMediaController socialMediaController;

    @FXML
    private Button loginButton;

    @FXML
    private Button logoutButton;


    public void setSocialMediaController(SocialMediaController socialMediaController) {
        this.socialMediaController = socialMediaController;
    }

    @FXML
    private void handleLoginButton(ActionEvent event) {
        if (!socialMediaController.isLoggedIn()) {
            // Leggi gli utenti registrati dal file Users.json
            List<User> registeredUsers = UserDataService.loadUsers();

            // Crea una finestra di dialogo per il login
            Dialog<Pair<String, String>> loginDialog = createLoginDialog();

            // Gestisci la risposta della finestra di dialogo
            Optional<Pair<String, String>> result = loginDialog.showAndWait();

            result.ifPresent(usernamePassword -> {
                String enteredUsername = usernamePassword.getKey();
                String enteredPassword = usernamePassword.getValue();

                // Verifica se l'utente è registrato e la password è corretta
                if (isValidLogin(registeredUsers, enteredUsername, enteredPassword)) {
                    System.out.println("Login successful as: " + enteredUsername);
                    socialMediaController.setCurrentUser(enteredUsername);
                    socialMediaController.setLoggedIn(true);

                    // Mostra un popup di benvenuto
                    showWelcomePopup(enteredUsername);
                } else {
                    System.out.println("Username or password is incorrect");
                }
            });
        } else {
            // Utente già loggato
            System.out.println("You are already logged in");
        }
    }

    private void showWelcomePopup(String username) {
        Alert welcomeAlert = new Alert(AlertType.INFORMATION);
        welcomeAlert.setTitle("Benvenuto");
        welcomeAlert.setHeaderText(null);
        welcomeAlert.setContentText("Benvenuto, " + username + " :-)");
        welcomeAlert.showAndWait();
    }

    private Dialog<Pair<String, String>> createLoginDialog() {
        Dialog<Pair<String, String>> loginDialog = new Dialog<>();
        loginDialog.setTitle("Login");
        loginDialog.setHeaderText("Enter username and password:");

        // Set the button types
        ButtonType loginButtonType = new ButtonType("Login", ButtonBar.ButtonData.OK_DONE);
        loginDialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

        // Create the username and password labels and fields
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);

        // Enable/Disable login button depending on whether a username was entered
        Node loginButton = loginDialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

        // Do some validation
        usernameField.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        loginDialog.getDialogPane().setContent(grid);

        // Convert the result to a username-password-pair when the login button is clicked
        loginDialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(usernameField.getText(), passwordField.getText());
            }
            return null;
        });

        return loginDialog;
    }

    private boolean isValidLogin(List<User> registeredUsers, String enteredUsername, String enteredPassword) {
        return registeredUsers.stream()
                .anyMatch(user -> user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword));
    }

    @FXML
    private void handleLogoutButton(ActionEvent event) {
        if (socialMediaController.isLoggedIn()) {
            // Effettua il logout
            socialMediaController.setLoggedIn(false);
            String currentUser = socialMediaController.getCurrentUser();

            // Mostra un popup di arrivederci
            showGoodbyePopup(currentUser);
            System.out.println("Logout successful for user: " + currentUser);
        } else {
            // Nessun utente loggato
            System.out.println("No user logged in");
        }
    }

    private void showGoodbyePopup(String username) {
        Alert goodbyeAlert = new Alert(AlertType.INFORMATION);
        goodbyeAlert.setTitle("Arrivederci");
        goodbyeAlert.setHeaderText(null);
        goodbyeAlert.setContentText("Arrivederci, " + username + " :-(");
        goodbyeAlert.showAndWait();
    }

}
