// UserDataService.java
package com.example.social2;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.example.social2.SocialMediaController.User;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public class UserDataService {

    private static final String USERS_FILE_PATH = "src/main/resources/com/example/social2/Users.json";

    public static List<SocialMediaController.User> loadUsers() {
        List<SocialMediaController.User> users = new ArrayList<>();

        try (FileReader fileReader = new FileReader(USERS_FILE_PATH)) {
            JSONParser jsonParser = new JSONParser();
            JSONArray jsonArray = (JSONArray) jsonParser.parse(fileReader);

            for (Object obj : jsonArray) {
                JSONObject userJson = (JSONObject) obj;
                String username = (String) userJson.get("username");
                String password = (String) userJson.get("password");

                users.add(new SocialMediaController.User(username, password));
            }

        } catch (IOException | ParseException e) {
            // Handle exception (file not found, parse error, etc.)
            e.printStackTrace();
        }

        return users;
    }

    public static void saveUsers(List<SocialMediaController.User> newUsers) {
        List<SocialMediaController.User> existingUsers = loadUsers();

        for (SocialMediaController.User newUser : newUsers) {
            // Verifica se il nuovo utente è già presente nella lista esistente
            boolean userExists = existingUsers.stream()
                    .anyMatch(user -> user.getUsername().equals(newUser.getUsername()));

            if (!userExists) {
                // Aggiungi il nuovo utente solo se non esiste già
                existingUsers.add(newUser);
            }
        }

        // Salva la lista combinata di utenti
        JSONArray jsonArray = new JSONArray();

        for (SocialMediaController.User user : existingUsers) {
            JSONObject userJson = new JSONObject();
            userJson.put("username", user.getUsername());
            userJson.put("password", user.getPassword());

            jsonArray.add(userJson);
        }

        try (FileWriter fileWriter = new FileWriter(USERS_FILE_PATH)) {
            fileWriter.write(jsonArray.toJSONString());
        } catch (IOException e) {
            // Handle exception (e.g., file not found, write error, etc.)
            e.printStackTrace();
        }
    }

    public static void eliminaUtente(String username) {
        List<User> existingUsers = loadUsers();

        // Rimuovi l'utente dalla lista
        existingUsers.removeIf(user -> user.getUsername().equals(username));

        // Salva la lista aggiornata di utenti nel file JSON
        JSONArray jsonArray = new JSONArray();

        for (User user : existingUsers) {
            JSONObject userJson = new JSONObject();
            userJson.put("username", user.getUsername());
            userJson.put("password", user.getPassword());

            jsonArray.add(userJson);
        }

        try (FileWriter fileWriter = new FileWriter(USERS_FILE_PATH)) {
            fileWriter.write(jsonArray.toJSONString());
        } catch (IOException e) {
            // Handle exception (e.g., file not found, write error, etc.)
            e.printStackTrace();
        }
    }
}
