package com.example.social2;
import java.util.List;
import java.io.IOException;

public interface NotificationSavingStrategy {
    void saveNotifications(List<NotificationController.Notification> notifications, String filePath) throws IOException;
}

