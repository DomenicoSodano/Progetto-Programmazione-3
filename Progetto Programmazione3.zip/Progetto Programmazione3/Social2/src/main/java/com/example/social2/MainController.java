package com.example.social2;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import java.io.IOException;
import javafx.scene.layout.VBox;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

public class MainController {

    @FXML
    private TextField usernameField;

    private Stage primaryStage;
    @FXML
    private PasswordField passwordField;

    private DataManager dataManager;  // Aggiungi un campo per DataManager


    public void setDataManager(DataManager dataManager) {
        this.dataManager = dataManager;
    }

    @FXML
    private void handleLoginButton() {
        // Implementa la logica di autenticazione qui
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Esempio di logica di autenticazione
        if ("admin".equals(username) && "admin".equals(password)) {
            showAlert("Login riuscito come Amministratore");
            // Aggiungi qui le azioni da eseguire dopo un login riuscito
        } else {
            showAlert("Credenziali non valide. Riprova.");
        }
    }

    @FXML
    public void handleAdminButtonClick(ActionEvent event) throws IOException {
        // Carica la schermata di login per l'amministratore
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/social2/AdminPassword.fxml"));
        Parent adminLoginRoot = loader.load();

        // Ottieni il controller dalla classe AdminPasswordController
        AdminPasswordController adminController = loader.getController();

        // Inizializza lo stage nella classe AdminPasswordController
        Stage adminLoginStage = new Stage();
        adminController.setAdminStage(adminLoginStage);

        // Crea una nuova scena e imposta lo stage
        Scene adminLoginScene = new Scene(adminLoginRoot, 300, 200);
        adminLoginStage.setScene(adminLoginScene);

        // Imposta il titolo dello stage
        adminLoginStage.setTitle("Login Amministratore");

        // Aggiungi il foglio di stile alla scena
        String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();
        adminLoginScene.getStylesheets().add(css);

        // Mostra la schermata di login per l'amministratore
        adminLoginStage.show();
    }



    @FXML
    private void handleUserButtonClick() {
        try {
            // Carica la schermata di SocialMediaApp
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SocialMedia.fxml"));
            Parent root = loader.load();

            // Ottieni il controller dalla classe SocialMediaController
            SocialMediaController socialMediaController = loader.getController();

            // Inizializza la referenza a MainController
            socialMediaController.setMainController(this);

            // Imposta la primaryStage nel controller
            socialMediaController.setPrimaryStage(primaryStage);

            // Crea una nuova scena e imposta lo stage
            Scene scene = new Scene(root, 400, 500);

            // Aggiungi lo stile alla scena
            String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage socialMediaStage = new Stage();
            socialMediaStage.setScene(scene);

            // Salva il riferimento allo Stage principale
            this.primaryStage = socialMediaStage;

            // Mostra la schermata di SocialMediaApp
            socialMediaStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Aggiungi un metodo per tornare alla schermata principale
    public void backToMainApp() {
        if (primaryStage != null) {
            primaryStage.close();
        } else {
            System.err.println("Errore: primaryStage è nullo.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Messaggio");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
