package com.example.social2;

interface UserBuilder {
    UserBuilder setUsername(String username);

    UserBuilder setHashedPassword(String hashedPassword);

    User build();
}