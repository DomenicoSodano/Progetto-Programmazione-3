package com.example.social2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;
import javafx.util.Callback;

public class AdminMessageMessaggio {

    public static class Messaggio {
        private final String contenuto;
        private final List<String> hashtags;

        public Messaggio(String contenuto, List<String> hashtags) {
            this.contenuto = contenuto;
            this.hashtags = hashtags;
        }

        public String getContenuto() {
            return contenuto;
        }

        public List<String> getHashtags() {
            return hashtags;
        }
    }
}
