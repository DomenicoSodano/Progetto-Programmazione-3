package com.example.social2;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PrivateChatController {

    @FXML
    private Label chatPartnerLabel;

    @FXML
    private TextArea chatArea;

    @FXML
    private TextArea messageInput;

    @FXML
    private Button sendButton;

    private String chatPartner;
    private Stage primaryStage;

    private PrivateChat privateChat;

    // Aggiunta di una lista per mantenere la cronologia dei messaggi
    private List<String> messageHistory = new ArrayList<>();


    public void setPrivateChat(PrivateChat privateChat) {
        this.privateChat = privateChat;
    }

    public void initialize(String chatPartner, Stage primaryStage) {
        this.chatPartner = chatPartner;
        this.primaryStage = primaryStage;
        chatPartnerLabel.setText("Chat with " + chatPartner);

        // Carica la cronologia dei messaggi dalla memoria
        loadMessageHistory();

        // Set the chatArea to be non-editable
        chatArea.setEditable(false);

        // Inizializza gli eventi
        initializeEvents();
    }

    // Aggiungi questo metodo per caricare la cronologia dei messaggi dalla memoria
    private void loadMessageHistory() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("messages_" + chatPartner + ".dat"))) {
            messageHistory = (List<String>) ois.readObject();
            messageHistory.forEach(message -> chatArea.appendText(message + "\n"));
        } catch (FileNotFoundException e) {
            // File non trovato (primo avvio della finestra di chat)
            messageHistory = new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            messageHistory = new ArrayList<>();
        }
    }


    private void initializeEvents() {
        sendButton.setOnAction(event -> sendMessage());
        // Aggiungi un evento per abilitare l'input di testo
        messageInput.setOnMouseClicked(event -> setMessageInputReadOnly(false));
    }

    @FXML
    private void sendMessage() {
        String message = messageInput.getText();
        if (!message.isEmpty() && privateChat != null) {
            // Aggiungi il messaggio alla cronologia
            messageHistory.add("You: " + message);
            // Aggiungi il messaggio alla chatArea
            chatArea.appendText("You: " + message + "\n");

            // Salva il messaggio sulla cronologia dei messaggi della finestra di chat
            saveMessageHistory();

            messageInput.clear();
        }
    }

    // Aggiungi questo metodo per salvare la cronologia dei messaggi su disco
    public void saveMessageHistory() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("messages_" + chatPartner + ".dat"))) {
            oos.writeObject(messageHistory);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Aggiungi questo metodo per caricare la cronologia dei messaggi dalla memoria

    public void addMessage(String message) {
        if (chatArea != null) {
            // Add the message to the message history
            messageHistory.add(message);

            // Add the message to the chatArea
            chatArea.appendText(message + "\n");
        } else {
            System.err.println("Error: chatArea is null");
        }
    }

    public void addFollowerMessage(String message) {
        if (chatArea != null) {
            // Customize the appearance of the message from a follower
            String formattedMessage = "[Follower] " + message;

            // Add the message to the message history
            messageHistory.add(formattedMessage);

            // Add the formatted message to the chatArea
            chatArea.appendText(formattedMessage + "\n");
        } else {
            System.err.println("Error: chatArea is null");
        }
    }



    public void setMessageInputReadOnly(boolean readOnly) {
        messageInput.setEditable(!readOnly);
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }
}
