package com.example.social2;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminPasswordController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private Stage adminStage;

    public void setAdminStage(Stage adminStage) {
        this.adminStage = adminStage;
    }

    @FXML
    private void handleLoginButton() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if ("admin".equals(username) && "admin".equals(password)) {
            adminStage.close();
            showAlert("Login riuscito come Amministratore");

            try {
                FXMLLoader welcomeLoader = new FXMLLoader(getClass().getResource("/com/example/social2/AdminWelcome.fxml"));
                Parent welcomeRoot = welcomeLoader.load();

                AdminWelcomeController welcomeController = welcomeLoader.getController();
                welcomeController.setWelcomeMessage(username);

                Scene welcomeScene = new Scene(welcomeRoot, 300, 200);
                Stage welcomeStage = new Stage();
                welcomeStage.setScene(welcomeScene);
                String css = getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm();
                welcomeScene.getStylesheets().add(css);

                welcomeStage.setTitle("Benvenuto Amministratore");
                welcomeStage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Errore durante il caricamento della schermata di benvenuto.");
            }
        } else {
            showAlert("Credenziali non valide. Riprova.");
        }
    }
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Messaggio");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
