package com.example.social2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.util.Callback;
import javafx.scene.control.Pagination;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.stream.Collectors;
import java.util.ArrayList;

public class AdminHashtagController implements InterfacciaObserver {

    @FXML
    private Pagination pagination;
    @FXML
    private ListView<AdminMessage.Messaggio> messaggiListView;

    @FXML
    private TextField nuovoMessaggioTextField;

    @FXML
    private ListView<AdminMessage.Messaggio> gattoListView;

    @FXML
    private ListView<AdminMessage.Messaggio> motoriListView;

    @FXML
    private ListView<AdminMessage.Messaggio> svagoListView;

    private final ObservableList<AdminMessage.Messaggio> messaggi = FXCollections.observableArrayList();

    public ListView<AdminMessage.Messaggio> getMessaggiListView() {
        return messaggiListView;
    }

    private static final int ITEMS_PER_PAGE = 4;

    private final AdminMessageNotifier notifier = new AdminMessageNotifier();

    @FXML
    public void initialize() {
        loadMessagesFromJson();
        messaggiListView.setCellFactory(createListCellCallback());

        // Filter messages with hashtags before setting them in the messaggiListView
        List<AdminMessage.Messaggio> messagesWithHashtags = filterMessagesByHashtagInPublic("#");
        messaggiListView.setItems(FXCollections.observableArrayList(messagesWithHashtags));

        // Set cell factories and update hashtag lists for other ListViews
        gattoListView.setCellFactory(createListCellCallback());
        motoriListView.setCellFactory(createListCellCallback());
        svagoListView.setCellFactory(createListCellCallback());

        // Filter and set messages in gattoListView, motoriListView, svagoListView
        gattoListView.setItems(FXCollections.observableArrayList(filterMessagesByHashtagInPublic("#gatti")));
        motoriListView.setItems(FXCollections.observableArrayList(filterMessagesByHashtagInPublic("#macchina")));
        svagoListView.setItems(FXCollections.observableArrayList(filterMessagesByHashtagInPublic("#musica")));
        PublicDataManager.setAdminHashtagController(this);

        notifier.addObserver(this);
    }

    public List<AdminMessage.Messaggio> filterMessagesByHashtagInPublic(String hashtag) {
        String lowercaseHashtag = hashtag.toLowerCase();

        return messaggi.stream()
                .filter(m -> {
                    List<String> hashtags = m.getHashtags();
                    return hashtags != null && hashtags.stream().anyMatch(h -> h.toLowerCase().contains(lowercaseHashtag));
                })
                .collect(Collectors.toList());
    }

    private Callback<ListView<AdminMessage.Messaggio>, ListCell<AdminMessage.Messaggio>> createListCellCallback() {
        return param -> new ListCell<>() {
            @Override
            protected void updateItem(AdminMessage.Messaggio item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.getContenuto().isEmpty()) {
                    setText(null);
                } else {
                    setText(item.getContenuto());
                }
            }
        };
    }

    private void loadMessagesFromJson() {
        messaggi.clear();

        try (FileReader fileReader = new FileReader("src/main/resources/com/example/social2/public.json")) {
            JSONParser jsonParser = new JSONParser();
            JSONArray jsonArray = (JSONArray) jsonParser.parse(fileReader);

            if (jsonArray.isEmpty()) {
                System.out.println("The JSON array is empty. No messages to load.");
                return;
            }

            for (Object obj : jsonArray) {
                JSONObject messageJson = (JSONObject) obj;
                List<String> hashtags = extractHashtags((String) messageJson.get("contenuto"));

                if (!hashtags.isEmpty()) {
                    String contenuto = (String) messageJson.get("contenuto");
                    messaggi.add(new AdminMessage.Messaggio(contenuto, hashtags));
                }
            }

            updateMessaggiListView();
            notifyMessageObservers(messaggi);
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    private void updateMessaggiListView() {
        List<AdminMessage.Messaggio> messagesWithHashtags = filterMessagesByHashtagInPublic("#");
        messaggiListView.setItems(FXCollections.observableArrayList(messagesWithHashtags));
    }

    private void notifyMessageObservers(List<AdminMessage.Messaggio> messages) {
        notifier.notifyObservers(messages);
    }

    private List<String> extractHashtags(String messageContent) {
        List<String> hashtags = new ArrayList<>();

        Pattern pattern = Pattern.compile("\\#\\w+");
        Matcher matcher = pattern.matcher(messageContent);

        while (matcher.find()) {
            hashtags.add(matcher.group());
        }

        return hashtags;
    }

    private List<AdminMessage.Messaggio> getMessagesForPage(int pageIndex) {
        int fromIndex = pageIndex * ITEMS_PER_PAGE;
        int toIndex = Math.min(fromIndex + ITEMS_PER_PAGE, messaggi.size());
        return messaggi.subList(fromIndex, toIndex);
    }

    private ListView<AdminMessage.Messaggio> createPage(int pageIndex) {
        return new ListView<>(FXCollections.observableArrayList(getMessagesForPage(pageIndex)));
    }

    @Override
    public void updateMessages(List<AdminMessage.Messaggio> messages) {
        messaggi.clear();
        messaggi.addAll(messages);

        updateMessaggiListView();
    }
}