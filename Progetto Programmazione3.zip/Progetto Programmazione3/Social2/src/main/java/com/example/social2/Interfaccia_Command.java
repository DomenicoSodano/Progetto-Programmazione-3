package com.example.social2;


    // Command.java
    public interface Interfaccia_Command {
        void execute();
    }

