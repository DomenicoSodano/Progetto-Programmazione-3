package com.example.social2;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.collections.FXCollections;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class PublicDataManager {

    private static final String PUBLIC_MESSAGES_FILE_PATH = "src/main/resources/com/example/social2/public.json";

    public static void addMessageToPublicChat(String messageContent, List<String> hashtags) {
        JSONObject messageJson = new JSONObject();
        messageJson.put("contenuto", messageContent);
        messageJson.put("hashtags", hashtags);

        List<JSONObject> publicMessages = loadPublicMessages();
        publicMessages.add(messageJson);

        // Aggiorna la messaggiListView nel AdminHashtagController
        updateMessaggiListView(hashtags);

        // Salva la lista aggiornata
        savePublicMessages(publicMessages);
    }




    private static void updateMessaggiListView(List<String> hashtags) {
        // Utilizza l'istanza del controller corrente senza creare un nuovo FXMLLoader
        if (adminHashtagController != null) {
            // Carica tutti i messaggi dal file JSON
            List<JSONObject> publicMessages = loadPublicMessages();

            // Estrai i messaggi con gli hashtag specificati
            List<AdminMessage.Messaggio> messagesWithHashtags = publicMessages.stream()
                    .filter(messageJson -> {
                        List<String> messageHashtags = (List<String>) messageJson.get("hashtags");
                        return messageHashtags != null && messageHashtags.containsAll(hashtags);
                    })
                    .map(AdminMessage.Messaggio::new)
                    .collect(Collectors.toList());

            // Aggiorna la messaggiListView nel AdminHashtagController
            adminHashtagController.getMessaggiListView().setItems(FXCollections.observableArrayList(messagesWithHashtags));
        }
    }


    private static AdminHashtagController adminHashtagController;  // Aggiungi questa variabile di classe

    public static void setAdminHashtagController(AdminHashtagController controller) {
        adminHashtagController = controller;
    }




    // Nuovo metodo per estrarre gli hashtag da una stringa di testo
    private static List<String> extractHashtags(String messageContent) {
        List<String> hashtags = new ArrayList<>();

        // Utilizza una espressione regolare per trovare tutte le parole che iniziano con #
        Pattern pattern = Pattern.compile("\\#\\w+");
        Matcher matcher = pattern.matcher(messageContent);

        while (matcher.find()) {
            hashtags.add(matcher.group());
        }

        return hashtags;
    }

    // Modifiche ai metodi loadPublicMessages e savePublicMessages
    public static List<JSONObject> loadPublicMessages() {
        List<JSONObject> publicMessages = new ArrayList<>();

        try (FileReader fileReader = new FileReader(PUBLIC_MESSAGES_FILE_PATH)) {
            JSONParser jsonParser = new JSONParser();
            Object parsedObject = jsonParser.parse(fileReader);

            if (parsedObject instanceof JSONArray) {
                JSONArray jsonArray = (JSONArray) parsedObject;

                for (Object obj : jsonArray) {
                    if (obj instanceof JSONObject) {
                        JSONObject messageJson = (JSONObject) obj;

                        // Extract hashtags from message content
                        String messageContent = (String) messageJson.get("contenuto");
                        List<String> hashtags = extractHashtags(messageContent);

                        // Update the hashtags field in the message JSON
                        messageJson.put("hashtags", hashtags);

                        publicMessages.add(messageJson);
                    }
                }
            } else {
                System.err.println("Il file JSON è vuoto.");
            }

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return publicMessages;
    }

    public static void savePublicMessages(List<JSONObject> publicMessages) {
        JSONArray jsonArray = new JSONArray();

        for (JSONObject messageJson : publicMessages) {
            jsonArray.add(messageJson);
        }

        try (FileWriter fileWriter = new FileWriter(PUBLIC_MESSAGES_FILE_PATH)) {
            fileWriter.write(jsonArray.toJSONString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

