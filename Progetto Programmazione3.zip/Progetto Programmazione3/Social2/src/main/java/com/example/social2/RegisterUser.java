package com.example.social2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;



public class RegisterUser extends Application {

    private static ObservableList<String> registeredUsersList = FXCollections.observableArrayList();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Registrazione Utente");

        try {
            // Caricamento del file FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("RegisterUser.fxml"));
            Parent root = loader.load();

            // Ottenere il controller associato al file FXML
            RegisterUserController controller = loader.getController();
            controller.setRegisterUserCallback(this::registerUser); // Use setRegisterUserCallback

            // Creazione della scena
            Scene scene = new Scene(root, 300, 200);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void registerUser(String username, String password) {
        if (!username.isEmpty() && !password.isEmpty()) {
            // Implementa la logica della registrazione dell'utente
            System.out.println("Utente registrato con successo!");
            System.out.println("Username: " + username);
            System.out.println("Password: " + password);

            // Aggiungi l'utente all'elenco degli utenti registrati
            registeredUsersList.add(username);
        } else {
            System.out.println("Inserisci sia l'username che la password.");
        }
    }

    // Aggiungi un metodo per ottenere l'elenco degli utenti registrati
    public static ObservableList<String> getRegisteredUsersList() {
        return registeredUsersList;
    }
}