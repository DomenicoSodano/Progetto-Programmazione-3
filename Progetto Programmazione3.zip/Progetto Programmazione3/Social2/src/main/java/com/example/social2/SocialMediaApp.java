package com.example.social2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.stage.Modality;
import java.io.IOException;

import java.util.Arrays;
import java.util.List;

public class SocialMediaApp extends Application {


    private SocialMediaController controller;  // New field
    private TextField searchBar;
    private Button searchButton;
    private ListView<String> userList;
    private Button followButton;
    private TextArea messageInput;
    private Label charCountLabel;

    private Stage primaryStage;  // Aggiungi questa dichiarazione


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Social Media App");
        this.primaryStage = primaryStage;  // Inizializza la variabile primaryStage



        // Carica il file FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SocialMedia.fxml"));
        Parent root = loader.load();

        // Ottenere il controller dalla classe SocialMediaController
        controller = loader.getController();  // Store the reference to the controller

        // Imposta la primaryStage nel controller
        controller.setPrimaryStage(primaryStage);

        // Inizializza i campi aggiunti
        searchBar = (TextField) root.lookup("#searchBar");
        searchButton = (Button) root.lookup("#searchButton");
        userList = (ListView<String>) root.lookup("#userList");
        followButton = (Button) root.lookup("#followButton");
        messageInput = (TextArea) root.lookup("#messageInput");
        charCountLabel = (Label) root.lookup("#charCountLabel");

        // Aggiungi il gestore di eventi per il pulsante di ricerca
        searchButton.setOnAction(event -> searchUsers());

        // Aggiungi il gestore di eventi per la selezione dell'utente
        userList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> showFollowButton());

        // Crea la scena
        Scene scene = new Scene(root, 400, 500);
        scene.getStylesheets().add(getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm());

        // Imposta la scena sullo stage
        primaryStage.setScene(scene);
        primaryStage.show();
        // Ottenere il controller dalla classe SocialMediaController
        controller = loader.getController();  // Store the reference to the controller

// Imposta la primaryStage nel controller
        controller.setPrimaryStage(primaryStage);
    }


    private void searchUsers() {
        String searchText = searchBar.getText().toLowerCase();
        userList.getItems().clear();

        // Aggiungi gli utenti predefiniti
        for (String user : getUsers()) {
            if (user.toLowerCase().contains(searchText)) {
                userList.getItems().add(user);
            }
        }

        // Aggiungi gli utenti registrati
        for (String user : controller.getRegisteredUsers()) {
            if (user.toLowerCase().contains(searchText)) {
                userList.getItems().add(user);
            }
        }
    }
    public void showUserDeletedNotification(String deletedUser) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Utente Eliminato");
        alert.setHeaderText(null);
        alert.setContentText("L'utente '" + deletedUser + "' è stato eliminato con successo.");
        alert.showAndWait();
    }


    private void showFollowButton() {
        String selectedUser = userList.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            followButton.setText("Follow " + selectedUser);
            followButton.setDisable(false);
        }
    }
    public void setMessageInputReadOnly(boolean readOnly) {
        messageInput.setEditable(!readOnly);
    }


    private List<String> getUsers() {
        return Arrays.asList("AlessandroU", "DomenicoS", "WalterM");
    }


}