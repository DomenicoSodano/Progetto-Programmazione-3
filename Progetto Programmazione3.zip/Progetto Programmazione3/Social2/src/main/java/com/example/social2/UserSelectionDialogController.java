package com.example.social2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;

import java.io.IOException;
import java.util.Map;

public class UserSelectionDialogController {
    private SocialMediaController socialMediaController;

    private boolean userSelected;
    private String selectedUser;
    @FXML
    private ChoiceBox<String> userChoiceBox;

    public boolean isUserSelected() {
        return userSelected;
    }

    public String getSelectedUser() {
        return selectedUser;
    }

    private String currentUser;
    private Map<String, PrivateChat> privateChats;

    public void initData(SocialMediaController socialMediaController, String selectedUser, Map<String, PrivateChat> privateChats) {
        this.socialMediaController = socialMediaController;
        this.selectedUser = selectedUser;
        this.privateChats = privateChats;


        // Ottieni la lista degli utenti che l'utente corrente segue
        ObservableList<String> followersList = FXCollections.observableArrayList(privateChats.keySet());
        userChoiceBox.setItems(followersList);
    }

    @FXML
    private void confirmUserSelection() {
        String recipient = userChoiceBox.getValue();
        if (recipient != null) {
            userSelected = true;
            selectedUser = recipient;
            Stage stage = (Stage) userChoiceBox.getScene().getWindow();
            stage.close();
        } else {
            // Show a notification or error message if no user is selected
        }
    }


    private void openPrivateChat(String currentUser, String recipient) {
        String chatKey = currentUser + "_" + recipient;
        PrivateChat privateChat = privateChats.get(chatKey);

        if (privateChat == null) {
            privateChat = new PrivateChat(recipient);
            privateChats.put(chatKey, privateChat);
        }

        // Aggiungi il messaggio all'istanza di PrivateChat
        String message = currentUser + " has started a chat.";
        privateChat.getController().addMessage(message);

        // Mostra la finestra di chat privata
        showPrivateChat(recipient, privateChat);
    }

    private void showPrivateChat(String selectedUser, PrivateChat privateChat) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("private_chat.fxml"));
            loader.setController(privateChat.getController()); // Usa il controller della finestra di chat privata

            // Carica il root dal file FXML
            Parent root = loader.load();

            Stage privateChatStage = new Stage();
            privateChatStage.initModality(Modality.APPLICATION_MODAL);
            privateChatStage.setTitle("Chat with " + selectedUser);

            Scene privateChatScene = new Scene(root);
            privateChatStage.setScene(privateChatScene);

            privateChatStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}