package com.example.social2;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Scene;

public class Log extends Application {

    private boolean isLoggedIn = false;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login/Logout");


        // Creazione dei pulsanti
        Button loginButton = new Button("Login");
        Button logoutButton = new Button("Logout");

        // Gestione degli eventi per il pulsante di login
        loginButton.setOnAction(event -> {
            if (!isLoggedIn) {
                // Mostra la finestra di dialogo per l'inserimento di username e password
                Dialog<Pair<String, String>> loginDialog = new Dialog<>();
                loginDialog.setTitle("Login");
                loginDialog.setHeaderText("Inserisci username e password:");

                // Imposta i pulsanti sulla finestra di dialogo
                ButtonType loginButtonType = new ButtonType("Login", ButtonBar.ButtonData.OK_DONE);
                loginDialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

                // Creazione di un GridPane per l'inserimento di username e password
                GridPane gridPane = new GridPane();
                gridPane.setHgap(10);
                gridPane.setVgap(10);
                gridPane.setPadding(new javafx.geometry.Insets(20, 150, 10, 10));

                // Campi di testo per l'inserimento di username e password
                TextField usernameField = new TextField();
                PasswordField passwordField = new PasswordField();

                gridPane.add(new Label("Username:"), 0, 0);
                gridPane.add(usernameField, 1, 0);
                gridPane.add(new Label("Password:"), 0, 1);
                gridPane.add(passwordField, 1, 1);

                loginDialog.getDialogPane().setContent(gridPane);

                // Abilita o disabilita il pulsante di login in base all'input dell'utente
                Button loginButtonOnDialog = (Button) loginDialog.getDialogPane().lookupButton(loginButtonType);
                loginButtonOnDialog.setDisable(true);

                // Aggiungi listener per abilitare o disabilitare il pulsante di login
                usernameField.textProperty().addListener((observable, oldValue, newValue) -> {
                    loginButtonOnDialog.setDisable(newValue.trim().isEmpty());
                });

                loginDialog.setResultConverter(dialogButton -> {
                    if (dialogButton == loginButtonType) {
                        return new Pair<>(usernameField.getText(), passwordField.getText());
                    }
                    return null;
                });

                // Visualizza la finestra di dialogo e ottieni l'input dell'utente
                loginDialog.showAndWait().ifPresent(result -> {
                    String username = result.getKey();
                    String password = result.getValue();

                    // Puoi aggiungere ulteriori controlli sulla password o autenticazione qui
                    if (!username.isEmpty() && !password.isEmpty()) {
                        System.out.println("Effettuato il login come: " + username);
                        isLoggedIn = true;
                    } else {
                        System.out.println("Login annullato");
                    }
                });
            } else {
                System.out.println("Sei già loggato");
            }
        });

        // Gestione degli eventi per il pulsante di logout
        logoutButton.setOnAction(event -> {
            if (isLoggedIn) {
                // Mostra la conferma del logout
                Alert logoutConfirmation = new Alert(Alert.AlertType.CONFIRMATION);
                logoutConfirmation.setTitle("Conferma Logout");
                logoutConfirmation.setHeaderText("Sei sicuro di fare il logout?");
                logoutConfirmation.initStyle(StageStyle.UTILITY);

                // Aggiungi i pulsanti Si e No alla finestra di conferma
                ButtonType buttonTypeYes = new ButtonType("Si");
                ButtonType buttonTypeNo = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
                logoutConfirmation.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

                // Gestione della risposta
                if (logoutConfirmation.showAndWait().orElse(buttonTypeNo) == buttonTypeYes) {
                    System.out.println("Effettuato il logout");
                    isLoggedIn = false;
                }
            } else {
                System.out.println("Non sei loggato");
            }
        });

        // Creazione del layout e aggiunta dei pulsanti
        VBox layout = new VBox(10);
        layout.getChildren().addAll(loginButton, logoutButton);

        // Creazione della scena e impostazione sullo stage
        Scene scene = new Scene(layout, 200, 150);
        primaryStage.setScene(scene);
        scene.getStylesheets().add(getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm());

        // Mostra lo stage
        primaryStage.show();
    }

    // Classe Pair generica per rappresentare una coppia di valori
    private static class Pair<K, V> {

        private final K key;
        private final V value;

        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }
}

