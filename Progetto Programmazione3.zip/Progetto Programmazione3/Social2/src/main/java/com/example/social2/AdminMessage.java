package com.example.social2;
import org.json.simple.JSONObject;
import java.util.ArrayList;

import java.util.List;
public class AdminMessage {

    public static class Messaggio {
        private String contenuto;
        private List<String> hashtags;

        public Messaggio(String contenuto, List<String> hashtags) {
            this.contenuto = contenuto;
            this.hashtags = hashtags != null ? new ArrayList<>(hashtags) : new ArrayList<>();
        }

        // Constructor to match JSONObject
        public Messaggio(JSONObject jsonObject) {
            this.contenuto = (String) jsonObject.get("contenuto");
            this.hashtags = (List<String>) jsonObject.get("hashtags");
        }

        public String getContenuto() {
            return contenuto;
        }

        public List<String> getHashtags() {
            return hashtags;
        }

        @Override
        public String toString() {
            return "Messaggio{" +
                    "contenuto='" + contenuto + '\'' +
                    ", hashtags=" + hashtags +
                    '}';
        }
    }
}
