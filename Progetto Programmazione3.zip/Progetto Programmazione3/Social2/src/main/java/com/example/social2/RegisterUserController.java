package com.example.social2;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class RegisterUserController {
    private Map<String, String> userDatabase = new HashMap<>();

    @FXML
    private TextField usernameInput;

    @FXML
    private PasswordField passwordInput;

    @FXML
    private Button registerButton;

    private BiConsumer<String, String> registerUserCallback;

    private CommandInvoker commandInvoker = new CommandInvoker();

    // Metodo per impostare il callback per la registrazione dell'utente
    public void setRegisterUserCallback(BiConsumer<String, String> registerUserCallback) {
        this.registerUserCallback = registerUserCallback;
    }

    // Metodo chiamato durante l'inizializzazione del controller
    @FXML
    public void initialize() {
        // Creazione del comando e associazione al CommandInvoker
        RegisterUserCommand registerUserCommand = new RegisterUserCommand(this);
        commandInvoker.setCommand(registerUserCommand);

        // Impostazione dell'azione del pulsante di registrazione
        registerButton.setOnAction(event -> commandInvoker.executeCommand());
    }

    // Metodo per registrare un nuovo utente
    @FXML
    public void registerUser() {
        String username = usernameInput.getText();
        String password = passwordInput.getText();

        if (validateInput(username, password)) {
            if (!userDatabase.containsKey(username)) {
                userDatabase.put(username, password);
                System.out.println("User registered successfully!");
                System.out.println("Username: " + username);
                System.out.println("Password: " + password);

                invokeCallback(username, password);
            } else {
                System.out.println("User already exists.");
            }
        }
    }

    // Metodo per invocare il callback dopo la registrazione dell'utente
    private void invokeCallback(String username, String password) {
        if (registerUserCallback != null) {
            registerUserCallback.accept(username, password);
        } else {
            System.out.println("Callback function is not set. Cannot register user.");
        }
    }
    private void showWelcomePopup(String username) {
        Alert welcomeAlert = new Alert(Alert.AlertType.INFORMATION);
        welcomeAlert.setTitle("Benvenuto");
        welcomeAlert.setHeaderText(null);
        welcomeAlert.setContentText("Benvenuto, " + username + " :-)");
        welcomeAlert.showAndWait();
    }

    // Metodo per validare l'input dell'utente
    private boolean validateInput(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            System.out.println("Please enter both username and password.");
            return false;
        }
        return true;
    }
}