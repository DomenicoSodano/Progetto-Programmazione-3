package com.example.social2;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DataManager {
    private List<String> predefinedUsers;

    private static DataManager instance;

    private DataManager() {
        predefinedUsers = new ArrayList<>(Arrays.asList("AlessandroU", "DomenicoS", "WalterM"));
    }

    public static DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }

    public List<String> getPredefinedUsers() {
        return predefinedUsers;
    }
}
