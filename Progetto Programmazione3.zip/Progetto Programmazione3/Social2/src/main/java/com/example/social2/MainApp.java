package com.example.social2;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        primaryStage.setTitle("Login App");
        Scene scene = new Scene(root, 600, 400);  // Dichiarare la variabile 'scene' qui
        primaryStage.setScene(scene);
        scene.getStylesheets().add(getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm());
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    // Metodo chiamato quando il pulsante Amministratore viene premuto
    public void handleAdminButtonClick() {
        showAlert("Accesso come Amministratore");
    }

    // Metodo chiamato quando il pulsante Utente viene premuto
    public void handleUserButtonClick() {
        showAlert("Accesso come Utente");
    }

    // Metodo di utilità per mostrare una finestra di dialogo
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Messaggio");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

