package com.example.social2;
//Pattern Utilizzati in questo blocco di codice: Factory Method, Observer Pattern e Strategy Pattern

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AdminHashtag extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("AdminMessageApp.fxml"));
        primaryStage.setTitle("Admin Message App");
        primaryStage.setScene(new Scene(root, 800, 600));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}

