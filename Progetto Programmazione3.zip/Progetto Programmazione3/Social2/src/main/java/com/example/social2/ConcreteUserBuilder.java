package com.example.social2;
class ConcreteUserBuilder implements UserBuilder {
    private String username;
    private String hashedPassword;

    @Override
    public UserBuilder setUsername(String username) {
        this.username = username;
        return this;
    }

    @Override
    public UserBuilder setHashedPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword;
        return this;
    }

    @Override
    public User build() {
        return new User(username, hashedPassword);
    }
}
