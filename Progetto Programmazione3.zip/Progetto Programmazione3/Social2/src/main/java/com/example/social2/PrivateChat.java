package com.example.social2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.Scene;

public class PrivateChat extends Application {


    private String chatPartner;
    private PrivateChatController controller;
    private Stage primaryStage;
    private String stylesheetPath;

    // Adding a list to keep the message history
    private static final List<String> messageHistory = new ArrayList<>();

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public PrivateChat() {
        // Default empty constructor
    }

    private boolean chatOpen;

    public boolean isChatOpen() {
        return chatOpen;
    }

    public void setChatOpen(boolean chatOpen) {
        this.chatOpen = chatOpen;
    }

    public PrivateChat(String chatPartner, PrivateChatController controller) {
        this.chatPartner = chatPartner;
        this.controller = controller;
    }

    @Override
    public void stop() {
        // Save the message history when the chat window is closed
        controller.saveMessageHistory();
    }

    public PrivateChat(String chatPartner) {
        this.chatPartner = chatPartner;
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        this.primaryStage = primaryStage;

        FXMLLoader loader = new FXMLLoader(getClass().getResource("private_chat.fxml"));
        Parent root = loader.load();

        // Create a new Scene object and set the stylesheet
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/com/example/social2/styles/styles.css").toExternalForm());

        controller = loader.getController();
        controller.setPrivateChat(this);

        // Initialize the chat window with the message history
        controller.initialize(chatPartner, primaryStage);

        primaryStage.setTitle("Private Chat Example");
        primaryStage.setScene(scene);  // Set the created Scene object
        primaryStage.show();
    }

    public PrivateChatController getController() {
        return controller;
    }

    // Method to set the primaryStage
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}

