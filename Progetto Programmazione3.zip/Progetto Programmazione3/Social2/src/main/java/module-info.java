module com.example.social2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires json.simple;


    opens com.example.social2 to javafx.fxml;// Apri il package contenente MainApp
    exports com.example.social2;
}
